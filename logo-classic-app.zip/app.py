import os, sqlite3, json, secrets, re, io, csv, zipfile, time, threading, tempfile
from pathlib import Path
from datetime import datetime, timedelta, date, timezone
from functools import wraps
from flask import Flask, request, jsonify, session, send_file, render_template
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

ROOT=Path(__file__).parent
DATA=Path(os.environ.get('DATA_DIR', ROOT/'data')); DATA.mkdir(parents=True, exist_ok=True); DATA.chmod(0o700)
UPLOADS=DATA/'uploads'; UPLOADS.mkdir(exist_ok=True)
DB=DATA/'clients.sqlite3'
SECRET=DATA/'.session_secret'
if not SECRET.exists(): SECRET.write_text(secrets.token_hex(32)); SECRET.chmod(0o600)
app=Flask(__name__)
app.secret_key=SECRET.read_text().strip()
HTTPS_MODE=os.getenv('COOKIE_SECURE','0')=='1'
app.config.update(MAX_CONTENT_LENGTH=30*1024*1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='None' if HTTPS_MODE else 'Lax', SESSION_COOKIE_SECURE=HTTPS_MODE, SESSION_COOKIE_PARTITIONED=HTTPS_MODE, PERMANENT_SESSION_LIFETIME=timedelta(hours=12))
STATUSES=['جديد','تم التواصل','بانتظار الرد','عرض سعر مرسل','قيد التنفيذ','مكتمل','مؤرشف']
SERVICES=['تصميم شعار','هوية بصرية','تصميم جرافيكي','تصاميم إعلانية','إدارة حسابات التواصل الاجتماعي','تصميم وتطوير المواقع','خدمات أخرى']
FIELDS=['full_name','company','phone','email','city','social_username','links','services','description','requirements','budget','first_contact','source','status','next_followup','notes','custom_fields']
JSON_FIELDS=['links','services','custom_fields']
login_attempts={}; lock=threading.Lock()
def now(): return datetime.now(timezone(timedelta(hours=3))).isoformat(timespec='seconds')
def today(): return datetime.now(timezone(timedelta(hours=3))).date()
def conn():
    c=sqlite3.connect(DB, timeout=15); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def init_db():
    with conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, name TEXT NOT NULL, auth_version INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT NOT NULL, company TEXT DEFAULT '', phone TEXT DEFAULT '', email TEXT DEFAULT '', city TEXT DEFAULT '', social_username TEXT DEFAULT '', links TEXT DEFAULT '[]', services TEXT DEFAULT '[]', description TEXT DEFAULT '', requirements TEXT DEFAULT '', budget REAL, first_contact TEXT DEFAULT '', source TEXT DEFAULT '', status TEXT DEFAULT 'جديد', next_followup TEXT DEFAULT '', notes TEXT DEFAULT '', custom_fields TEXT DEFAULT '{}', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, last_contact TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS activities(id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE, kind TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS attachments(id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE, filename TEXT NOT NULL, storage_name TEXT NOT NULL, size INTEGER NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS ix_phone ON clients(phone);
        CREATE INDEX IF NOT EXISTS ix_followup ON clients(next_followup);
        ''')
        if 'auth_version' not in [r['name'] for r in c.execute('PRAGMA table_info(users)')]: c.execute('ALTER TABLE users ADD COLUMN auth_version INTEGER NOT NULL DEFAULT 0')
init_db()
TOKEN=DATA/'.setup_token'
with conn() as c: needs_setup=c.execute('SELECT count(*) FROM users').fetchone()[0]==0
if needs_setup and not TOKEN.exists(): TOKEN.write_text(secrets.token_urlsafe(18)); TOKEN.chmod(0o600)
if needs_setup:
    access_file = (ROOT if DATA.resolve()==(ROOT/'data').resolve() else DATA)/'ACCESS.txt'
    access_file.write_text('LOGO CLASSIC — إعداد حساب المالك\n\nافتح التطبيق واختر الدخول إلى لوحة التحكم.\nأنشئ حسابك ببريدك وكلمة مرور قوية، وأدخل رمز التهيئة التالي:\n\n'+TOKEN.read_text()+'\n\nهذا الرمز يُستخدم مرة واحدة فقط. احذف هذا الملف بعد إنشاء الحساب. لا تشارك رمز التهيئة.\n')
    access_file.chmod(0o600)

def auth(f):
    @wraps(f)
    def inner(*a,**kw):
        if not session.get('uid'): return jsonify(error='يرجى تسجيل الدخول أولًا'),401
        with conn() as c: u=c.execute('SELECT auth_version FROM users WHERE id=?',(session['uid'],)).fetchone()
        if not u or session.get('v',0)!=u['auth_version']:
            session.clear(); return jsonify(error='انتهت الجلسة؛ يرجى تسجيل الدخول مجددًا'),401
        if request.method not in ('GET','HEAD','OPTIONS') and (not session.get('csrf') or not secrets.compare_digest(request.headers.get('X-CSRF-Token',''), session['csrf'])): return jsonify(error='انتهت جلسة الحماية؛ حدّث الصفحة'),403
        return f(*a,**kw)
    return inner

def decoded(row):
    d=dict(row)
    for k in JSON_FIELDS: d[k]=json.loads(d[k] or ('{}' if k=='custom_fields' else '[]'))
    return d

def activity(c,cid,kind,text): c.execute('INSERT INTO activities(client_id,kind,content,created_at) VALUES(?,?,?,?)',(cid,kind,text,now()))
def normalize_phone(s):
    s=str(s or '').translate(str.maketrans('٠١٢٣٤٥٦٧٨٩','0123456789'))
    s=re.sub(r'[^0-9]','',s)
    if s.startswith('00966'): s=s[2:]
    if s.startswith('05') and len(s)==10: s='966'+s[1:]
    return s

def validate(d):
    out={k:d.get(k, {} if k=='custom_fields' else [] if k in JSON_FIELDS else '') for k in FIELDS}
    for k in FIELDS:
        if k not in JSON_FIELDS and k!='budget':
            if not isinstance(out[k],str): raise ValueError('صيغة غير صحيحة: '+k)
            out[k]=out[k].strip()
            if len(out[k])>20000: raise ValueError('النص أطول من الحد المسموح')
    if not out['full_name']: raise ValueError('اسم العميل مطلوب')
    if len(out['full_name'])>200: raise ValueError('اسم العميل طويل جدًا')
    if out['status'] not in STATUSES: raise ValueError('حالة العميل غير صحيحة')
    if not isinstance(out['services'],list) or any(s not in SERVICES for s in out['services']): raise ValueError('الخدمات غير صحيحة')
    if not isinstance(out['links'],list) or len(out['links'])>30 or any(not isinstance(x,str) or not re.match(r'^https?://[^\s]+$',x) for x in out['links']): raise ValueError('روابط الحسابات يجب أن تبدأ بـ https:// أو http://')
    if not isinstance(out['custom_fields'],dict) or len(json.dumps(out['custom_fields']))>20000 or any(not isinstance(v,str) for v in out['custom_fields'].values()): raise ValueError('الحقول المخصصة غير صحيحة')
    out['email']=out['email'].lower()
    if out['email'] and not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$',out['email']): raise ValueError('البريد الإلكتروني غير صحيح')
    out['phone']=normalize_phone(out['phone'])
    if out['phone'] and not 8<=len(out['phone'])<=15: raise ValueError('رقم الجوال غير صحيح')
    for k in ['first_contact','next_followup']:
        if out[k]:
            try: date.fromisoformat(out[k])
            except ValueError: raise ValueError('تاريخ غير صحيح')
    if out['budget'] in ('',None): out['budget']=None
    else:
        try: out['budget']=float(out['budget'])
        except (TypeError,ValueError): raise ValueError('الميزانية يجب أن تكون رقمًا')
        if not 0<=out['budget']<=1e10: raise ValueError('الميزانية خارج النطاق')
    return out

def duplicates(c,d,cid=0):
    return [dict(r) for r in c.execute('SELECT id,full_name,company,phone,email FROM clients WHERE id!=? AND ((phone!=\'\' AND phone=?) OR (email!=\'\' AND email=?))',(cid,d['phone'],d['email']))]

def encoded(d): return [json.dumps(d[k],ensure_ascii=False) if k in JSON_FIELDS else d[k] for k in FIELDS]

@app.get('/')
@app.get('/app')
@app.get('/client/<int:cid>')
def index(cid=None): return render_template('index.html')

@app.get('/api/session')
def get_session():
    with conn() as c:
        setup=c.execute('SELECT count(*) FROM users').fetchone()[0]==0
        u=c.execute('SELECT id,name,email,auth_version FROM users WHERE id=?',(session.get('uid',0),)).fetchone()
    if u and session.get('v',0)!=u['auth_version']: session.clear(); u=None
    if not session.get('csrf'): session['csrf']=secrets.token_hex(24)
    user={k:u[k] for k in ['id','name','email']} if u else None
    return jsonify(user=user, setup=setup, csrf=session['csrf'])

def require_origin():
    # CSRF token must be obtained from this origin before any authentication request.
    return bool(session.get('csrf')) and secrets.compare_digest(request.headers.get('X-CSRF-Token',''),session['csrf'])

@app.post('/api/setup')
def setup():
    if not require_origin(): return jsonify(error='حدّث الصفحة وحاول مجددًا'),403
    d=request.get_json() or {}
    with lock,conn() as c:
        c.execute('BEGIN IMMEDIATE')
        if c.execute('SELECT count(*) FROM users').fetchone()[0]: return jsonify(error='تم إعداد الحساب مسبقًا'),403
        if not TOKEN.exists() or not secrets.compare_digest(str(d.get('token','')),TOKEN.read_text().strip()): return jsonify(error='رمز التهيئة غير صحيح؛ راجع ملف ACCESS.txt'),403
        email=str(d.get('email','')).strip().lower(); password=str(d.get('password','')); name=str(d.get('name','')).strip()
        if not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$',email) or len(email)>254 or not 10<=len(password)<=1000 or not name: return jsonify(error='أدخل اسمك وبريدًا صحيحًا وكلمة مرور من 10 أحرف على الأقل'),400
        cur=c.execute('INSERT INTO users(email,password,name) VALUES(?,?,?)',(email,generate_password_hash(password),name[:100]))
        uid=cur.lastrowid
    TOKEN.unlink(missing_ok=True)
    session.clear(); session.update(uid=uid,v=0,csrf=secrets.token_hex(24)); session.permanent=True
    return jsonify(ok=True,csrf=session['csrf'])

@app.post('/api/login')
def login():
    if not require_origin(): return jsonify(error='حدّث الصفحة وحاول مجددًا'),403
    d=request.get_json() or {}; ip=request.remote_addr; t=time.time()
    attempts=login_attempts.get(ip,[]); attempts=[x for x in attempts if t-x<900]
    if len(attempts)>=12: return jsonify(error='محاولات كثيرة؛ حاول بعد 15 دقيقة'),429
    with conn() as c: u=c.execute('SELECT * FROM users WHERE email=?',(str(d.get('email','')).strip().lower(),)).fetchone()
    if not u or not check_password_hash(u['password'],str(d.get('password',''))):
        login_attempts[ip]=attempts+[t]; return jsonify(error='البريد أو كلمة المرور غير صحيح'),401
    login_attempts.pop(ip,None); session.clear(); session.update(uid=u['id'],v=u['auth_version'],csrf=secrets.token_hex(24)); session.permanent=True
    return jsonify(ok=True,csrf=session['csrf'])

@app.post('/api/logout')
@auth
def logout(): session.clear(); return jsonify(ok=True)

@app.get('/api/clients')
@auth
def clients():
    args=request.args; clauses=[]; vals=[]
    if args.get('q'):
        q='%'+args['q'].strip()+'%'; clauses.append('(full_name LIKE ? OR company LIKE ? OR phone LIKE ? OR email LIKE ? OR notes LIKE ? OR description LIKE ? OR requirements LIKE ? OR services LIKE ?)'); vals.extend([q]*8)
    for k in ['status','city','source']:
        if args.get(k): clauses.append(k+'=?'); vals.append(args[k])
    if args.get('service'): clauses.append('services LIKE ?'); vals.append('%'+args['service']+'%')
    for key,op in [('from','>='),('to','<=')]:
        if args.get(key): clauses.append('substr(created_at,1,10) '+op+' ?'); vals.append(args[key])
    where=' WHERE '+' AND '.join(clauses) if clauses else ''
    with conn() as c: rows=c.execute('SELECT * FROM clients'+where+' ORDER BY created_at DESC,id DESC',vals).fetchall()
    return jsonify([decoded(r) for r in rows])

@app.get('/api/stats')
@auth
def stats():
    with conn() as c:
        rows=[decoded(x) for x in c.execute('SELECT * FROM clients ORDER BY created_at DESC,id DESC')]
    active=[x for x in rows if x['status']!='مؤرشف']; td=today().isoformat()
    return jsonify(total=len(active),new=sum(x['status']=='جديد' for x in active),active=sum(x['status']=='قيد التنفيذ' for x in active),completed=sum(x['status']=='مكتمل' for x in active),followups=[x for x in active if x['status']!='مكتمل' and x['next_followup'] and x['next_followup']<=td],upcoming=[x for x in active if x['status']!='مكتمل' and x['next_followup']>td],stale=[x for x in active if x['status']!='مكتمل' and (x['last_contact'] or x['created_at'])[:10] <= (today()-timedelta(days=14)).isoformat()],recent=active[:5])

@app.post('/api/clients')
@auth
def create_client():
    raw=request.get_json() or {}
    try: d=validate(raw)
    except ValueError as e: return jsonify(error=str(e)),400
    with conn() as c:
        c.execute('BEGIN IMMEDIATE')
        dup=duplicates(c,d)
        if dup and not raw.get('confirm_duplicate'): return jsonify(error='يوجد عميل بنفس الجوال أو البريد. راجع السجل قبل المتابعة.',duplicates=dup),409
        t=now(); cur=c.execute('INSERT INTO clients('+','.join(FIELDS)+',created_at,updated_at) VALUES('+','.join(['?']*(len(FIELDS)+2))+')',encoded(d)+[t,t]); cid=cur.lastrowid
        activity(c,cid,'created','تم إنشاء ملف العميل'+(' بعد مراجعة التكرار' if dup else ''))
    return jsonify(id=cid),201

@app.get('/api/clients/<int:cid>')
@auth
def client_detail(cid):
    with conn() as c:
        r=c.execute('SELECT * FROM clients WHERE id=?',(cid,)).fetchone()
        if not r: return jsonify(error='العميل غير موجود'),404
        d=decoded(r); d['activities']=[dict(x) for x in c.execute('SELECT * FROM activities WHERE client_id=? ORDER BY id DESC',(cid,))]; d['attachments']=[dict(x) for x in c.execute('SELECT id,client_id,filename,size,created_at FROM attachments WHERE client_id=? ORDER BY id DESC',(cid,))]
    return jsonify(d)

@app.put('/api/clients/<int:cid>')
@auth
def update_client(cid):
    raw=request.get_json() or {}
    with conn() as c:
        c.execute('BEGIN IMMEDIATE')
        old=c.execute('SELECT * FROM clients WHERE id=?',(cid,)).fetchone()
        if not old: return jsonify(error='العميل غير موجود'),404
        prev=decoded(old)
        try: d=validate({**prev,**raw})
        except ValueError as e: return jsonify(error=str(e)),400
        dup=duplicates(c,d,cid)
        if dup and not raw.get('confirm_duplicate') and (d['phone']!=prev['phone'] or d['email']!=prev['email']): return jsonify(error='توجد بيانات اتصال مطابقة لعميل آخر',duplicates=dup),409
        changes=[k for k in FIELDS if d[k]!=prev[k]]
        c.execute('UPDATE clients SET '+','.join(k+'=?' for k in FIELDS)+',updated_at=? WHERE id=?',encoded(d)+[now(),cid])
        if changes: activity(c,cid,'updated',json.dumps({'fields':changes,'before':{k:prev[k] for k in changes},'after':{k:d[k] for k in changes}},ensure_ascii=False))
    return jsonify(ok=True)

@app.delete('/api/clients/<int:cid>')
@auth
def delete_client(cid):
    with conn() as c:
        files=c.execute('SELECT storage_name FROM attachments WHERE client_id=?',(cid,)).fetchall()
        c.execute('DELETE FROM clients WHERE id=?',(cid,))
    for x in files: (UPLOADS/x[0]).unlink(missing_ok=True)
    return jsonify(ok=True)

@app.post('/api/clients/<int:cid>/activities')
@auth
def add_activity(cid):
    d=request.get_json() or {}; content=str(d.get('content','')).strip(); kind=d.get('kind','note')
    if not content or len(content)>20000 or kind not in ['note','call','whatsapp','email','meeting','instagram']: return jsonify(error='أدخل ملاحظة أو نتيجة التواصل بشكل صحيح'),400
    with conn() as c:
        if not c.execute('SELECT id FROM clients WHERE id=?',(cid,)).fetchone(): return jsonify(error='العميل غير موجود'),404
        activity(c,cid,kind,content)
        c.execute('UPDATE clients SET updated_at=?'+(',last_contact=?' if kind!='note' else '')+' WHERE id=?',([now(),now(),cid] if kind!='note' else [now(),cid]))
    return jsonify(ok=True),201

@app.post('/api/clients/<int:cid>/attachments')
@auth
def upload(cid):
    f=request.files.get('file')
    if not f or not f.filename: return jsonify(error='اختر ملفًا'),400
    with conn() as c:
        if not c.execute('SELECT id FROM clients WHERE id=?',(cid,)).fetchone(): return jsonify(error='العميل غير موجود'),404
        name=secrets.token_hex(24); f.save(UPLOADS/name); size=(UPLOADS/name).stat().st_size
        if size>20*1024*1024: (UPLOADS/name).unlink(); return jsonify(error='الحد الأقصى للملف 20 ميجابايت'),400
        c.execute('INSERT INTO attachments(client_id,filename,storage_name,size,created_at) VALUES(?,?,?,?,?)',(cid,Path(f.filename).name[:240],name,size,now()))
        activity(c,cid,'file','تم إرفاق: '+Path(f.filename).name[:240])
    return jsonify(ok=True),201

@app.get('/api/attachments/<int:aid>')
@auth
def download_attachment(aid):
    with conn() as c: r=c.execute('SELECT * FROM attachments WHERE id=?',(aid,)).fetchone()
    if not r or not (UPLOADS/r['storage_name']).exists(): return jsonify(error='الملف غير موجود'),404
    return send_file(UPLOADS/r['storage_name'],as_attachment=True,download_name=r['filename'],mimetype='application/octet-stream')

@app.delete('/api/attachments/<int:aid>')
@auth
def delete_attachment(aid):
    with conn() as c:
        r=c.execute('SELECT * FROM attachments WHERE id=?',(aid,)).fetchone()
        if r:
            c.execute('DELETE FROM attachments WHERE id=?',(aid,)); activity(c,r['client_id'],'file','حُذف المرفق: '+r['filename']); (UPLOADS/r['storage_name']).unlink(missing_ok=True)
    return jsonify(ok=True)

@app.route('/api/settings',methods=['GET','PUT'])
@auth
def settings():
    with conn() as c:
        if request.method=='PUT':
            d=request.get_json() or {}; fields=d.get('custom_fields',[])
            if not isinstance(fields,list) or len(fields)>30 or any(not isinstance(f,str) or len(f)>100 or not f.strip() for f in fields) or len(set(fields))!=len(fields): return jsonify(error='أسماء الحقول يجب أن تكون فريدة، حتى 30 حقلًا'),400
            c.execute('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)',('custom_fields',json.dumps(fields,ensure_ascii=False)))
        r=c.execute('SELECT value FROM settings WHERE key=?',('custom_fields',)).fetchone()
    return jsonify(custom_fields=json.loads(r[0]) if r else [])

@app.get('/api/export')
@auth
def export():
    with conn() as c:
        if request.args.get('id'): rows=c.execute('SELECT * FROM clients WHERE id=?',(request.args['id'],)).fetchall()
        else: rows=c.execute('SELECT * FROM clients ORDER BY id').fetchall()
    names=['الاسم','النشاط التجاري','الجوال','البريد الإلكتروني','المدينة','حساب التواصل','الروابط','الخدمات','وصف الطلب','المتطلبات','الميزانية','أول تواصل','المصدر','الحالة','المتابعة القادمة','الملاحظات','حقول مخصصة','تاريخ الإنشاء','آخر تحديث','آخر تواصل']
    keys=FIELDS+['created_at','updated_at','last_contact']; s=io.StringIO(); w=csv.writer(s); w.writerow(names)
    for r in rows:
        d=decoded(r); values=[]
        for k in keys:
            v=d.get(k,''); v=json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else str(v if v is not None else '')
            if v.lstrip().startswith(('=','+','-','@','\t','\r')): v="'"+v
            values.append(v)
        w.writerow(values)
    return send_file(io.BytesIO(s.getvalue().encode('utf-8-sig')),mimetype='text/csv; charset=utf-8',as_attachment=True,download_name='logo-classic-clients.csv')

@app.get('/api/activities')
@auth
def all_activities():
    with conn() as c:
        rows=c.execute("SELECT a.*, c.full_name,c.company FROM activities a JOIN clients c ON c.id=a.client_id WHERE a.kind NOT IN ('updated','created','file') ORDER BY a.id DESC LIMIT 500").fetchall()
    return jsonify([dict(r) for r in rows])

@app.post('/api/password')
@auth
def change_password():
    d=request.get_json() or {}
    with conn() as c:
        u=c.execute('SELECT * FROM users WHERE id=?',(session['uid'],)).fetchone()
        if not check_password_hash(u['password'],str(d.get('current',''))): return jsonify(error='كلمة المرور الحالية غير صحيحة'),400
        if not 10<=len(str(d.get('new','')))<=1000: return jsonify(error='كلمة المرور الجديدة لا تقل عن 10 أحرف'),400
        c.execute('UPDATE users SET password=?,auth_version=auth_version+1 WHERE id=?',(generate_password_hash(d['new']),session['uid']))
        session['v']=u['auth_version']+1
    session['csrf']=secrets.token_hex(24)
    return jsonify(ok=True,csrf=session['csrf'])

def make_backup():
    with conn() as c:
        c.execute('BEGIN')
        payload={'version':1,'created_at':now(),'clients':[dict(x) for x in c.execute('SELECT * FROM clients')],'activities':[dict(x) for x in c.execute('SELECT * FROM activities')],'attachments':[dict(x) for x in c.execute('SELECT * FROM attachments')],'settings':[dict(x) for x in c.execute('SELECT * FROM settings')]}
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:
            z.writestr('backup.json',json.dumps(payload,ensure_ascii=False))
            for a in payload['attachments']:
                if (UPLOADS/a['storage_name']).exists(): z.write(UPLOADS/a['storage_name'],'uploads/'+a['storage_name'])
    b.seek(0); return b

@app.get('/api/backup')
@auth
def backup():
    return send_file(make_backup(),as_attachment=True,download_name=f'logo-classic-backup-{today()}.zip',mimetype='application/zip')

@app.post('/api/restore')
@auth
def restore():
    f=request.files.get('file')
    if not f: return jsonify(error='اختر نسخة احتياطية'),400
    staged=[]
    try:
        z=zipfile.ZipFile(f); infos=z.infolist()
        if sum(i.file_size for i in infos)>150*1024*1024 or len(infos)>10000: raise ValueError('النسخة كبيرة جدًا')
        d=json.loads(z.read('backup.json'))
        if d.get('version')!=1: raise ValueError('إصدار غير مدعوم')
        # Validate complete backup before changing database or files; never extract arbitrary paths.
        client_ids=set()
        for row in d['clients']:
            validate({**row,**{k:json.loads(row[k]) for k in JSON_FIELDS}}); client_ids.add(int(row['id']))
        if len(client_ids)!=len(d['clients']): raise ValueError('معرفات مكررة')
        files={}
        for a in d['attachments']:
            if a['client_id'] not in client_ids or not re.fullmatch(r'[a-f0-9]{48}',a['storage_name']): raise ValueError('مرفق غير صحيح')
            new_name=secrets.token_hex(24)
            files[new_name]=z.read('uploads/'+a['storage_name'])
            a['storage_name']=new_name
        for a in d['activities']:
            if a['client_id'] not in client_ids: raise ValueError('سجل غير صحيح')
        with lock,conn() as c:
            c.execute('BEGIN IMMEDIATE')
            old_files=[r[0] for r in c.execute('SELECT storage_name FROM attachments')]
            c.execute('DELETE FROM clients'); c.execute('DELETE FROM settings')
            for table,columns in [('clients',['id']+FIELDS+['created_at','updated_at','last_contact']),('activities',['id','client_id','kind','content','created_at']),('attachments',['id','client_id','filename','storage_name','size','created_at']),('settings',['key','value'])]:
                for row in d[table]: c.execute('INSERT INTO '+table+'('+','.join(columns)+') VALUES('+','.join('?' for _ in columns)+')',[row[k] for k in columns])
            for name,content in files.items():
                staged.append(UPLOADS/name); (UPLOADS/name).write_bytes(content)
        for name in old_files:
            try: (UPLOADS/name).unlink(missing_ok=True)
            except OSError: pass
        return jsonify(ok=True)
    except Exception:
        for path in staged:
            try: path.unlink(missing_ok=True)
            except OSError: pass
        return jsonify(error='نسخة غير صالحة أو غير مكتملة. لم تُستبدل بيانات قاعدة العملاء.'),400

# Conservative deterministic extraction: no external AI and no invented missing fields.
def parse_arabic(text):
    t=text.translate(str.maketrans('٠١٢٣٤٥٦٧٨٩','0123456789')).replace('٬','').replace('٫','.'); result={'status':'جديد','description':text,'services':[]}; found=[]
    patterns=[('full_name',r'(?:اسمه|اسمها|باسم|اسم العميل|الاسم)\s+([^،,.\n]+?)(?=\s+(?:عنده|عندها|لديه|لديها|يحتاج|تحتاج|رقمه|من|ميزاني|وصاحب|صاحب)|[،,.\n]|$)'),('company',r'(?:عنده|عندها|لديه|لديها)\s+(.+?)(?=\s+(?:في|يحتاج|تحتاج|ميزاني)|[،,.\n]|$)'),('budget',r'(?:ميزانيته|ميزانيتها|ميزاني[ةه]|الميزانية)\s*(?:حوالي|تقدر بـ|بـ|ب|هي)?\s*([0-9]+(?:[.,][0-9]+)?)')]
    for k,p in patterns:
        m=re.search(p,t)
        if m: result[k]=float(m[1].replace(',','') if re.fullmatch(r'[0-9]{1,3},[0-9]{3}',m[1]) else m[1].replace(',','.')) if k=='budget' else m[1].strip(); found.append(k)
    for city in ['الرياض','جدة','مكة','المدينة المنورة','الدمام','الخبر','الطائف','أبها','تبوك','بريدة','حائل','جازان','نجران']:
        if re.search(r'(?:في|من|بمدينة)\s+'+city,t): result['city']=city; found.append('city'); break
    variants={'تصميم شعار':['شعار','لوجو'],'هوية بصرية':['هوية بصرية','هويه بصريه'],'تصميم جرافيكي':['جرافيك'],'تصاميم إعلانية':['إعلانية','اعلانية'],'إدارة حسابات التواصل الاجتماعي':['إدارة حسابات','ادارة حسابات'],'تصميم وتطوير المواقع':['تصميم موقع','تطوير موقع','موقع إلكتروني']}
    for service,words in variants.items():
        if any(w in t for w in words): result['services'].append(service)
    for source,words in {'واتساب':['واتساب','واتس أب','واتس اب'],'إنستغرام':['إنستغرام','انستغرام','إنستقرام','انستقرام'],'الموقع الإلكتروني':['عن طريق الموقع','من الموقع'],'إحالة':['إحالة','احالة']}.items():
        if any(w in t for w in words): result['source']=source; found.append('source'); break
    m=re.search(r'(?:\+?966|05)[\d\s-]{7,15}',t)
    if m:
        p=normalize_phone(m[0])
        if 9<=len(p)<=15: result['phone']=p; found.append('phone')
    m=re.search(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',t)
    if m: result['email']=m[0]; found.append('email')
    warnings=['الاستخراج مبدئي وليس خدمة ذكاء اصطناعي خارجية؛ راجع كل الحقول قبل الحفظ.']
    if re.search(r'(?:أتابع|اتابع|متابعة|تابع|أتواصل)',t):
        follow=None
        explicit=re.search(r'\b(20[0-9]{2}-[0-9]{2}-[0-9]{2})\b',t)
        if explicit:
            try: follow=date.fromisoformat(explicit[1])
            except ValueError: pass
        if follow: pass
        elif 'غدًا' in t or 'بكرة' in t or 'غدا' in t: follow=today()+timedelta(days=1)
        elif 'اليوم' in t: follow=today()
        else:
            for day,i in [('الاثنين',0),('الإثنين',0),('الثلاثاء',1),('الأربعاء',2),('الاربعاء',2),('الخميس',3),('الجمعة',4),('السبت',5),('الأحد',6),('الاحد',6)]:
                if day in t:
                    delta=(i-today().weekday())%7 or 7; follow=today()+timedelta(days=delta); warnings.append('تم اقتراح أقرب '+day+' قادم؛ تأكد من التاريخ المقصود.'); break
        if follow: result['next_followup']=follow.isoformat(); found.append('next_followup')
    if result['services']: found.append('services')
    return {'fields':result,'extracted':found,'warnings':warnings}

@app.post('/api/parse')
@auth
def parse():
    t=str((request.get_json() or {}).get('text','')).strip()
    if not t or len(t)>12000: return jsonify(error='أدخل نصًا من 1 إلى 12000 حرف'),400
    return jsonify(parse_arabic(t))

@app.before_request
def validate_json_request():
    if request.path.startswith('/api/') and request.is_json:
        d=request.get_json(silent=True)
        if not isinstance(d,dict): return jsonify(error='يجب أن تكون البيانات كائن JSON صالحًا'),400
        if any(isinstance(d.get(k),str) and len(d[k])>1000 for k in ['password','current','new','token']): return jsonify(error='قيمة الإدخال أطول من المسموح'),400

@app.after_request
def headers(r):
    r.headers['X-Content-Type-Options']='nosniff'; r.headers['Referrer-Policy']='same-origin'
    r.headers['Permissions-Policy']='microphone=(self)'
    r.headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'"
    if request.path.startswith('/api/'): r.headers['Cache-Control']='no-store'
    return r

@app.errorhandler(413)
def too_large(e): return jsonify(error='حجم الطلب كبير جدًا؛ الحد 30 ميجابايت'),413

if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.getenv('PORT','3000')),debug=False)
