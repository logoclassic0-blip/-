"""Owner-only server maintenance. Never expose this script through HTTP."""
import argparse
import getpass
import os
from pathlib import Path
from app import conn, make_backup, today
from werkzeug.security import generate_password_hash

parser=argparse.ArgumentParser(description='LOGO CLASSIC server maintenance')
sub=parser.add_subparsers(dest='command',required=True)
b=sub.add_parser('backup',help='Create a ZIP compatible with the UI restore screen')
b.add_argument('output',nargs='?',default=f'backups/logo-classic-{today()}.zip')
r=sub.add_parser('reset-password',help='Reset owner password interactively, revoking all sessions')
r.add_argument('email')
a=parser.parse_args()
if a.command=='backup':
    path=Path(a.output).resolve();path.parent.mkdir(parents=True,exist_ok=True)
    data=make_backup()
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(fd,'wb') as f: f.write(data.getvalue())
    print('Backup saved:',path)
elif a.command=='reset-password':
    email=a.email.strip().lower()
    with conn() as c:
        user=c.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()
        if not user: raise SystemExit('Account not found.')
        password=getpass.getpass('New password (10+ characters): ')
        if not 10<=len(password)<=1000: raise SystemExit('Password must be 10–1000 characters.')
        if password!=getpass.getpass('Confirm password: '): raise SystemExit('Passwords do not match.')
        c.execute('UPDATE users SET password=?,auth_version=auth_version+1 WHERE id=?',(generate_password_hash(password),user['id']))
    print('Password reset. All previous sessions have been revoked.')
